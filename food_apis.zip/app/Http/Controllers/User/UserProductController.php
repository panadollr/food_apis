<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

use App\Models\Product;
use App\Models\Category;

class UserProductController
{
    
    public function getProducts(Request $request){
        $category_id = $request->category_id;
        $type = $request->type;
        if ($category_id && Category::find($category_id)) {
            $products = Product::where('category_id', $category_id)->paginate(12);
        } else if($type == "moi-nhat"){
            $products = Product::orderBy('id','desc')->take(8)->get();
        } else if($type == "ban-chay"){
            $products = Product::join('order_details', 'order_details.product_id', 'products.id')
            ->orderBy('order_details.product_quantity', 'desc')
            ->select('products.id', 'products.name', 'products.images', 'products.old_price', 'products.new_price', 'products.description')
            ->selectRaw('SUM(order_details.product_quantity) as product_quantity')
            ->groupBy('products.id', 'products.name', 'products.images', 'products.old_price', 'products.new_price', 'products.description', 'product_quantity')
            ->take(8)->get();
        } else {
            $products = Product::paginate(12);
        }

        $products->each(function ($product) {
            $product->images = json_decode($product->images);
        });
           
        return $products;
    }

    public function searchProducts(Request $request){
        $product_name = $request->product_name;
        $existingProducts = Product::where('name', 'LIKE', '%' . $product_name . '%')->get();

        if(count($existingProducts) > 0){
            return ['success' => $existingProducts];
        } else {
            return ['error' => 'Không tìm thấy sản phẩm !'];
        }
    }
  

   
}
